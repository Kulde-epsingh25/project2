css_content = """:root {
/* Primitive Color Tokens */
--color-white: rgba(255, 255, 255, 1);
--color-black: rgba(0, 0, 0, 1);
--color-cream-50: rgba(252, 252, 249, 1);
--color-cream-100: rgba(255, 255, 253, 1);
--color-gray-200: rgba(245, 245, 245, 1);
--color-gray-300: rgba(167, 169, 169, 1);
--color-gray-400: rgba(119, 124, 124, 1);
--color-slate-500: rgba(98, 108, 113, 1);
--color-brown-600: rgba(94, 82, 64, 1);
--color-charcoal-700: rgba(31, 33, 33, 1);
--color-charcoal-800: rgba(38, 40, 40, 1);
--color-slate-900: rgba(19, 52, 59, 1);
--color-teal-300: rgba(50, 184, 198, 1);
--color-teal-400: rgba(45, 166, 178, 1);
--color-teal-500: rgba(33, 128, 141, 1);
--color-teal-600: rgba(29, 116, 128, 1);
--color-teal-700: rgba(26, 104, 115, 1);
--color-teal-800: rgba(41, 150, 161, 1);
--color-red-400: rgba(255, 84, 89, 1);
--color-red-500: rgba(192, 21, 47, 1);
--color-orange-400: rgba(230, 129, 97, 1);
--color-orange-500: rgba(168, 75, 47, 1);

/* RGB versions for opacity control */
--color-brown-600-rgb: 94, 82, 64;
--color-teal-500-rgb: 33, 128, 141;
--color-slate-900-rgb: 19, 52, 59;
--color-slate-500-rgb: 98, 108, 113;
--color-red-500-rgb: 192, 21, 47;
--color-red-400-rgb: 255, 84, 89;
--color-orange-500-rgb: 168, 75, 47;
--color-orange-400-rgb: 230, 129, 97;

/* Background color tokens (Light Mode) */
--color-bg-1: rgba(59, 130, 246, 0.08);
--color-bg-2: rgba(245, 158, 11, 0.08);
--color-bg-3: rgba(34, 197, 94, 0.08);
--color-bg-4: rgba(239, 68, 68, 0.08);
--color-bg-5: rgba(147, 51, 234, 0.08);

/* Semantic Color Tokens (Light Mode) */
--color-background: var(--color-cream-50);
--color-surface: var(--color-cream-100);
--color-text: var(--color-slate-900);
--color-text-secondary: var(--color-slate-500);
--color-primary: var(--color-teal-500);
--color-primary-hover: var(--color-teal-600);
--color-primary-active: var(--color-teal-700);
--color-secondary: rgba(var(--color-brown-600-rgb), 0.12);
--color-secondary-hover: rgba(var(--color-brown-600-rgb), 0.2);
--color-secondary-active: rgba(var(--color-brown-600-rgb), 0.25);
--color-border: rgba(var(--color-brown-600-rgb), 0.2);
--color-btn-primary-text: var(--color-cream-50);
--color-card-border: rgba(var(--color-brown-600-rgb), 0.12);
--color-card-border-inner: rgba(var(--color-brown-600-rgb), 0.12);
--color-error: var(--color-red-500);
--color-success: var(--color-teal-500);
--color-warning: var(--color-orange-500);
--color-info: var(--color-slate-500);
--color-focus-ring: rgba(var(--color-teal-500-rgb), 0.4);

/* Typography */
--font-family-base: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
--font-size-xs: 11px;
--font-size-sm: 12px;
--font-size-base: 14px;
--font-size-md: 14px;
--font-size-lg: 16px;
--font-size-xl: 18px;
--font-size-2xl: 20px;
--font-size-3xl: 24px;
--font-size-4xl: 30px;
--font-weight-normal: 400;
--font-weight-medium: 500;
--font-weight-semibold: 550;
--font-weight-bold: 600;
--line-height-tight: 1.2;
--line-height-normal: 1.5;

/* Spacing */
--space-4: 4px;
--space-8: 8px;
--space-12: 12px;
--space-16: 16px;
--space-20: 20px;
--space-24: 24px;
--space-32: 32px;

/* Border Radius */
--radius-sm: 6px;
--radius-base: 8px;
--radius-lg: 12px;
--radius-full: 9999px;

/* Shadows */
--shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.04), 0 1px 2px rgba(0, 0, 0, 0.02);
--shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.04), 0 2px 4px -1px rgba(0, 0, 0, 0.02);
--shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.04), 0 4px 6px -2px rgba(0, 0, 0, 0.02);

/* Animation */
--duration-fast: 150ms;
--duration-normal: 250ms;
--ease-standard: cubic-bezier(0.16, 1, 0.3, 1);
}

/* Dark mode colors */
@media (prefers-color-scheme: dark) {
:root {
--color-background: var(--color-charcoal-700);
--color-surface: var(--color-charcoal-800);
--color-text: var(--color-gray-200);
--color-text-secondary: rgba(var(--color-gray-300), 0.7);
--color-primary: var(--color-teal-300);
--color-primary-hover: var(--color-teal-400);
--color-primary-active: var(--color-teal-800);
--color-secondary: rgba(var(--color-gray-400), 0.15);
--color-secondary-hover: rgba(var(--color-gray-400), 0.25);
--color-secondary-active: rgba(var(--color-gray-400), 0.3);
--color-border: rgba(var(--color-gray-400), 0.3);
--color-error: var(--color-red-400);
--color-success: var(--color-teal-300);
--color-warning: var(--color-orange-400);
--color-info: var(--color-gray-300);
--color-btn-primary-text: var(--color-slate-900);
--color-card-border: rgba(var(--color-gray-400), 0.2);
--color-card-border-inner: rgba(var(--color-gray-400), 0.15);
}
}

[data-color-scheme="dark"] {
--color-background: var(--color-charcoal-700);
--color-surface: var(--color-charcoal-800);
--color-text: var(--color-gray-200);
--color-text-secondary: rgba(167, 169, 169, 0.7);
--color-primary: var(--color-teal-300);
--color-primary-hover: var(--color-teal-400);
--color-primary-active: var(--color-teal-800);
--color-secondary: rgba(119, 124, 124, 0.15);
--color-secondary-hover: rgba(119, 124, 124, 0.25);
--color-secondary-active: rgba(119, 124, 124, 0.3);
--color-border: rgba(119, 124, 124, 0.3);
--color-error: var(--color-red-400);
--color-success: var(--color-teal-300);
--color-warning: var(--color-orange-400);
--color-info: var(--color-gray-300);
--color-btn-primary-text: var(--color-slate-900);
--color-card-border: rgba(119, 124, 124, 0.15);
--color-card-border-inner: rgba(119, 124, 124, 0.15);
}

[data-color-scheme="light"] {
--color-background: var(--color-cream-50);
--color-surface: var(--color-cream-100);
--color-text: var(--color-slate-900);
--color-text-secondary: var(--color-slate-500);
--color-primary: var(--color-teal-500);
--color-primary-hover: var(--color-teal-600);
--color-primary-active: var(--color-teal-700);
--color-secondary: rgba(94, 82, 64, 0.12);
--color-secondary-hover: rgba(94, 82, 64, 0.2);
--color-secondary-active: rgba(94, 82, 64, 0.25);
--color-border: rgba(94, 82, 64, 0.2);
--color-btn-primary-text: var(--color-cream-50);
--color-card-border: rgba(94, 82, 64, 0.12);
--color-card-border-inner: rgba(94, 82, 64, 0.12);
--color-error: var(--color-red-500);
--color-success: var(--color-teal-500);
--color-warning: var(--color-orange-500);
--color-info: var(--color-slate-500);
}

/* Base styles */
html {
font-size: var(--font-size-base);
font-family: var(--font-family-base);
line-height: var(--line-height-normal);
color: var(--color-text);
background-color: var(--color-background);
-webkit-font-smoothing: antialiased;
box-sizing: border-box;
}

body {
margin: 0;
padding: 0;
}

*, *::before, *::after {
box-sizing: inherit;
}

/* Typography */
h1, h2, h3, h4, h5, h6 {
margin: 0;
font-weight: var(--font-weight-semibold);
line-height: var(--line-height-tight);
color: var(--color-text);
}

h1 { font-size: var(--font-size-4xl); }
h2 { font-size: var(--font-size-3xl); }
h3 { font-size: var(--font-size-2xl); }
h4 { font-size: var(--font-size-xl); }
h5 { font-size: var(--font-size-lg); }
h6 { font-size: var(--font-size-md); }

p {
margin: 0 0 var(--space-16) 0;
}

/* Buttons */
.btn {
display: inline-flex;
align-items: center;
justify-content: center;
padding: var(--space-8) var(--space-16);
border-radius: var(--radius-base);
font-size: var(--font-size-base);
font-weight: 500;
line-height: 1.5;
cursor: pointer;
transition: all var(--duration-normal) var(--ease-standard);
border: none;
text-decoration: none;
position: relative;
}

.btn--primary {
background: var(--color-primary);
color: var(--color-btn-primary-text);
}

.btn--primary:hover {
background: var(--color-primary-hover);
}

.btn--outline {
background: transparent;
border: 1px solid var(--color-border);
color: var(--color-text);
}

.btn--outline:hover {
background: var(--color-secondary);
}

.btn:disabled {
opacity: 0.5;
cursor: not-allowed;
}

/* Form elements */
.form-control {
display: block;
width: 100%;
padding: var(--space-8) var(--space-12);
font-size: var(--font-size-md);
line-height: 1.5;
color: var(--color-text);
background-color: var(--color-surface);
border: 1px solid var(--color-border);
border-radius: var(--radius-base);
transition: border-color var(--duration-fast) var(--ease-standard);
}

.form-control:focus {
border-color: var(--color-primary);
outline: 2px solid var(--color-primary);
}

textarea.form-control {
font-family: var(--font-family-base);
resize: vertical;
}

select.form-control {
-webkit-appearance: none;
-moz-appearance: none;
appearance: none;
}

/* Card component */
.card {
background-color: var(--color-surface);
border-radius: var(--radius-lg);
border: 1px solid var(--color-card-border);
box-shadow: var(--shadow-sm);
overflow: hidden;
transition: box-shadow var(--duration-normal) var(--ease-standard);
}

.card:hover {
box-shadow: var(--shadow-md);
}

/* Header */
.header {
background: linear-gradient(135deg, var(--color-primary), var(--color-teal-700));
color: var(--color-white);
padding: var(--space-12) 0;
position: fixed;
top: 0;
left: 0;
right: 0;
z-index: 1000;
height: 60px;
box-shadow: var(--shadow-md);
}

.header-content {
max-width: 1400px;
margin: 0 auto;
display: flex;
justify-content: space-between;
align-items: center;
padding: 0 var(--space-20);
}

.logo {
display: flex;
align-items: center;
gap: var(--space-12);
}

.logo i {
font-size: var(--font-size-2xl);
}

.logo h1 {
font-size: var(--font-size-xl);
font-weight: var(--font-weight-bold);
margin: 0;
}

.nav {
display: flex;
align-items: center;
gap: var(--space-16);
}

.api-status {
display: flex;
align-items: center;
gap: var(--space-8);
font-size: var(--font-size-sm);
color: rgba(255, 255, 255, 0.9);
}

.theme-toggle {
background: rgba(255, 255, 255, 0.1);
border: 1px solid rgba(255, 255, 255, 0.2);
color: var(--color-white);
padding: var(--space-8);
border-radius: var(--radius-base);
cursor: pointer;
transition: all var(--duration-fast) var(--ease-standard);
}

.theme-toggle:hover {
background: rgba(255, 255, 255, 0.2);
}

/* Layout */
.main-layout {
display: grid;
grid-template-columns: 200px 1fr 250px;
height: calc(100vh - 60px);
gap: 0;
}

.sidebar-left {
background: var(--color-surface);
border-right: 1px solid var(--color-border);
padding: var(--space-20) 0;
margin-top: 60px;
min-width: 200px;
}

.sidebar-nav {
display: flex;
flex-direction: column;
gap: var(--space-8);
padding: 0 var(--space-16);
}

.nav-item {
display: flex;
align-items: center;
gap: var(--space-12);
padding: var(--space-12) var(--space-16);
background: transparent;
border: none;
border-radius: var(--radius-base);
color: var(--color-text-secondary);
font-size: var(--font-size-base);
cursor: pointer;
transition: all var(--duration-fast) var(--ease-standard);
text-align: left;
width: 100%;
}

.nav-item:hover {
background: var(--color-secondary);
color: var(--color-text);
}

.nav-item.active {
background: var(--color-primary);
color: var(--color-btn-primary-text);
}

.main-content {
background: var(--color-background);
overflow: hidden;
margin-top: 60px;
position: relative;
}

.content-section {
display: none;
height: 100%;
overflow-y: auto;
padding: var(--space-20);
}

.content-section.active {
display: block;
}

.sidebar-right {
background: var(--color-surface);
border-left: 1px solid var(--color-border);
padding: var(--space-20);
margin-top: 60px;
overflow-y: auto;
min-width: 250px;
}

/* Chat Interface */
.chat-container {
display: flex;
flex-direction: column;
height: 100%;
max-width: 800px;
margin: 0 auto;
}

.chat-header {
display: flex;
justify-content: space-between;
align-items: center;
padding: var(--space-16);
background: var(--color-surface);
border-radius: var(--radius-lg) var(--radius-lg) 0 0;
border: 1px solid var(--color-border);
border-bottom: none;
}

.chat-status {
display: flex;
align-items: center;
gap: var(--space-8);
font-size: var(--font-size-sm);
color: var(--color-text-secondary);
}

.status-indicator {
width: 8px;
height: 8px;
border-radius: 50%;
background: var(--color-success);
}

.status-indicator.online {
animation: pulse 2s infinite;
}

.status-indicator.offline {
background: var(--color-error);
animation: none;
}

@keyframes pulse {
0% { opacity: 1; }
50% { opacity: 0.5; }
100% { opacity: 1; }
}

.chat-messages {
flex: 1;
padding: var(--space-20);
background: var(--color-surface);
border-left: 1px solid var(--color-border);
border-right: 1px solid var(--color-border);
overflow-y: auto;
display: flex;
flex-direction: column;
gap: var(--space-16);
min-height: 400px;
max-height: calc(100vh - 300px);
}

.message {
display: flex;
gap: var(--space-12);
max-width: 80%;
animation: messageSlide 0.3s var(--ease-standard);
}

@keyframes messageSlide {
from {
opacity: 0;
transform: translateY(10px);
}
to {
opacity: 1;
transform: translateY(0);
}
}

.user-message {
align-self: flex-end;
flex-direction: row-reverse;
}

.bot-message {
align-self: flex-start;
}

.message-avatar {
width: 32px;
height: 32px;
border-radius: 50%;
display: flex;
align-items: center;
justify-content: center;
font-size: var(--font-size-sm);
flex-shrink: 0;
}

.bot-message .message-avatar {
background: var(--color-primary);
color: var(--color-btn-primary-text);
}

.user-message .message-avatar {
background: var(--color-bg-1);
color: var(--color-text);
}

.message-content {
flex: 1;
}

.message-text {
padding: var(--space-12) var(--space-16);
border-radius: var(--radius-lg);
font-size: var(--font-size-base);
line-height: var(--line-height-normal);
word-wrap: break-word;
white-space: pre-wrap;
}

.user-message .message-text {
background: var(--color-primary);
color: var(--color-btn-primary-text);
border-bottom-right-radius: var(--radius-sm);
}

.bot-message .message-text {
background: var(--color-bg-2);
border-bottom-left-radius: var(--radius-sm);
color: var(--color-text);
}

.message-time {
font-size: var(--font-size-xs);
color: var(--color-text-secondary);
margin-top: var(--space-4);
text-align: right;
}

.bot-message .message-time {
text-align: left;
}

.sentiment-indicator {
display: inline-flex;
align-items: center;
gap: var(--space-4);
font-size: var(--font-size-xs);
margin-top: var(--space-4);
padding: var(--space-4) var(--space-8);
border-radius: var(--radius-full);
}

.sentiment-indicator.positive {
background: rgba(33, 128, 141, 0.1);
color: var(--color-success);
}

.sentiment-indicator.negative {
background: rgba(192, 21, 47, 0.1);
color: var(--color-error);
}

.sentiment-indicator.neutral {
background: rgba(98, 108, 113, 0.1);
color: var(--color-info);
}

.typing-indicator {
display: flex;
align-items: center;
gap: var(--space-8);
padding: var(--space-12) var(--space-20);
color: var(--color-text-secondary);
font-size: var(--font-size-sm);
}

.typing-indicator.hidden {
display: none;
}

.typing-dots {
display: flex;
gap: var(--space-4);
}

.typing-dots span {
width: 4px;
height: 4px;
border-radius: 50%;
background: var(--color-text-secondary);
animation: typing 1.4s infinite;
}

.typing-dots span:nth-child(2) {
animation-delay: 0.2s;
}

.typing-dots span:nth-child(3) {
animation-delay: 0.4s;
}

@keyframes typing {
0%, 60%, 100% {
transform: scale(1);
opacity: 0.5;
}
30% {
transform: scale(1.2);
opacity: 1;
}
}

.chat-input {
background: var(--color-surface);
border: 1px solid var(--color-border);
border-top: none;
border-radius: 0 0 var(--radius-lg) var(--radius-lg);
padding: var(--space-16);
}

.input-container {
display: flex;
align-items: flex-end;
gap: var(--space-12);
background: var(--color-background);
border: 1px solid var(--color-border);
border-radius: var(--radius-lg);
padding: var(--space-8) var(--space-16);
}

#messageInput {
flex: 1;
border: none;
background: transparent;
font-size: var(--font-size-base);
color: var(--color-text);
padding: var(--space-8) 0;
resize: none;
min-height: 20px;
max-height: 120px;
font-family: var(--font-family-base);
}

#messageInput:focus {
outline: none;
}

.input-actions {
display: flex;
align-items: center;
gap: var(--space-12);
}

.char-count {
font-size: var(--font-size-xs);
color: var(--color-text-secondary);
min-width: 50px;
}

.send-btn {
width: 36px;
height: 36px;
border-radius: 50%;
border: none;
background: var(--color-primary);
color: var(--color-btn-primary-text);
cursor: pointer;
transition: all var(--duration-fast) var(--ease-standard);
display: flex;
align-items: center;
justify-content: center;
}

.send-btn:hover {
background: var(--color-primary-hover);
transform: scale(1.05);
}

.send-btn:disabled {
background: var(--color-text-secondary);
cursor: not-allowed;
transform: none;
opacity: 0.5;
}

.quick-replies {
display: flex;
gap: var(--space-8);
margin-top: var(--space-12);
flex-wrap: wrap;
}

.quick-reply {
padding: var(--space-8) var(--space-12);
background: var(--color-secondary);
border: 1px solid var(--color-border);
border-radius: var(--radius-full);
font-size: var(--font-size-sm);
color: var(--color-text);
cursor: pointer;
transition: all var(--duration-fast) var(--ease-standard);
}

.quick-reply:hover {
background: var(--color-secondary-hover);
transform: translateY(-1px);
}

/* Analytics Styles */
.analytics-container h2 {
margin-bottom: var(--space-32);
color: var(--color-text);
}

.analytics-grid {
display: grid;
grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
gap: var(--space-20);
margin-bottom: var(--space-32);
}

.stat-card {
background: var(--color-surface);
border: 1px solid var(--color-border);
border-radius: var(--radius-lg);
padding: var(--space-20);
text-align: center;
transition: all var(--duration-normal) var(--ease-standard);
}

.stat-card:hover {
transform: translateY(-2px);
box-shadow: var(--shadow-lg);
}

.stat-value {
font-size: var(--font-size-4xl);
font-weight: var(--font-weight-bold);
color: var(--color-primary);
margin-bottom: var(--space-8);
}

.stat-label {
font-size: var(--font-size-sm);
color: var(--color-text-secondary);
font-weight: var(--font-weight-medium);
}

.charts-container {
display: grid;
grid-template-columns: 1fr 1fr;
gap: var(--space-32);
}

.chart-card {
background: var(--color-surface);
border: 1px solid var(--color-border);
border-radius: var(--radius-lg);
padding: var(--space-20);
}

.chart-card h3 {
margin-bottom: var(--space-16);
color: var(--color-text);
}

/* Settings Styles */
.settings-container h2 {
margin-bottom: var(--space-32);
color: var(--color-text);
}

.settings-group {
background: var(--color-surface);
border: 1px solid var(--color-border);
border-radius: var(--radius-lg);
padding: var(--space-20);
margin-bottom: var(--space-20);
}

.settings-group h3 {
margin-bottom: var(--space-16);
color: var(--color-text);
font-size: var(--font-size-lg);
}

.setting-item {
margin-bottom: var(--space-16);
}

.setting-item:last-child {
margin-bottom: 0;
}

.setting-item label {
display: block;
margin-bottom: var(--space-8);
font-weight: var(--font-weight-medium);
color: var(--color-text);
}

.checkbox-label {
display: flex;
align-items: center;
gap: var(--space-8);
cursor: pointer;
}

.checkbox-label input[type="checkbox"] {
margin: 0;
}

input[type="range"] {
width: 100%;
height: 6px;
border-radius: var(--radius-sm);
background: var(--color-secondary);
outline: none;
-webkit-appearance: none;
}

input[type="range"]::-webkit-slider-thumb {
-webkit-appearance: none;
width: 20px;
height: 20px;
border-radius: 50%;
background: var(--color-primary);
cursor: pointer;
}

input[type="range"]::-moz-range-thumb {
width: 20px;
height: 20px;
border-radius: 50%;
background: var(--color-primary);
cursor: pointer;
border: none;
}

.settings-actions {
display: flex;
gap: var(--space-16);
flex-wrap: wrap;
}

/* About Styles */
.about-container h2 {
margin-bottom: var(--space-32);
color: var(--color-text);
}

.about-content {
display: grid;
grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
gap: var(--space-24);
}

.feature-card {
background: var(--color-surface);
border: 1px solid var(--color-border);
border-radius: var(--radius-lg);
padding: var(--space-24);
text-align: center;
transition: all var(--duration-normal) var(--ease-standard);
}

.feature-card:hover {
transform: translateY(-4px);
box-shadow: var(--shadow-lg);
}

.feature-icon {
width: 60px;
height: 60px;
margin: 0 auto var(--space-16);
background: var(--color-bg-3);
border-radius: 50%;
display: flex;
align-items: center;
justify-content: center;
font-size: var(--font-size-2xl);
color: var(--color-primary);
}

.feature-card h3 {
margin-bottom: var(--space-12);
color: var(--color-text);
}

.feature-card p {
color: var(--color-text-secondary);
line-height: var(--line-height-normal);
}

/* Right Sidebar Styles */
.sidebar-right h3 {
margin-bottom: var(--space-16);
color: var(--color-text);
font-size: var(--font-size-lg);
}

.user-info, .recent-topics {
margin-bottom: var(--space-32);
}

.session-stats {
background: var(--color-bg-4);
border-radius: var(--radius-base);
padding: var(--space-16);
}

.stat-item {
display: flex;
justify-content: space-between;
align-items: center;
margin-bottom: var(--space-12);
}

.stat-item:last-child {
margin-bottom: 0;
}

.stat-item .stat-label {
font-size: var(--font-size-sm);
color: var(--color-text-secondary);
}

.stat-item .stat-value {
font-weight: var(--font-weight-medium);
color: var(--color-text);
}

.sentiment {
padding: var(--space-4) var(--space-8);
border-radius: var(--radius-full);
font-size: var(--font-size-xs);
}

.sentiment.positive {
background: rgba(33, 128, 141, 0.1);
color: var(--color-success);
}

.sentiment.negative {
background: rgba(192, 21, 47, 0.1);
color: var(--color-error);
}

.sentiment.neutral {
background: rgba(98, 108, 113, 0.1);
color: var(--color-info);
}

.topics-list {
background: var(--color-bg-5);
border-radius: var(--radius-base);
padding: var(--space-16);
}

.topic-item {
padding: var(--space-8) var(--space-12);
background: var(--color-surface);
border-radius: var(--radius-sm);
margin-bottom: var(--space-8);
font-size: var(--font-size-sm);
color: var(--color-text);
border: 1px solid var(--color-border);
}

.topic-item:last-child {
margin-bottom: 0;
}

/* Mobile Navigation */
.mobile-nav {
display: none;
background: var(--color-surface);
border-bottom: 1px solid var(--color-border);
padding: var(--space-8);
position: fixed;
top: 60px;
left: 0;
right: 0;
z-index: 999;
}

.mobile-nav-items {
display: flex;
justify-content: space-around;
align-items: center;
}

.mobile-nav-item {
display: flex;
flex-direction: column;
align-items: center;
gap: var(--space-4);
padding: var(--space-8);
background: transparent;
border: none;
color: var(--color-text-secondary);
cursor: pointer;
transition: color var(--duration-fast) var(--ease-standard);
font-size: var(--font-size-xs);
}

.mobile-nav-item.active,
.mobile-nav-item:hover {
color: var(--color-primary);
}

.mobile-nav-item i {
font-size: var(--font-size-lg);
}

/* Error Message Styles */
.error-message {
background: rgba(192, 21, 47, 0.1);
border: 1px solid rgba(192, 21, 47, 0.3);
color: var(--color-error);
padding: var(--space-12) var(--space-16);
border-radius: var(--radius-base);
margin: var(--space-8) 0;
font-size: var(--font-size-sm);
}

/* Responsive Design */
@media (max-width: 1200px) {
.main-layout {
grid-template-columns: 180px 1fr 220px;
}

.charts-container {
grid-template-columns: 1fr;
}
}

@media (max-width: 1024px) {
.main-layout {
grid-template-columns: 1fr;
}

.sidebar-left {
display: none;
}

.sidebar-right {
display: none;
}

.mobile-nav {
display: block;
}

.content-section {
margin-top: 100px;
}

.about-content {
grid-template-columns: 1fr;
}
}

@media (max-width: 768px) {
.header-content {
padding: 0 var(--space-16);
}

.logo h1 {
font-size: var(--font-size-lg);
}

.content-section {
padding: var(--space-16);
}

.analytics-grid {
grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
gap: var(--space-16);
}

.quick-replies {
flex-direction: column;
}

.settings-actions {
flex-direction: column;
}

.settings-actions .btn {
width: 100%;
}

.mobile-nav-items {
gap: var(--space-4);
}

.mobile-nav-item {
min-width: 60px;
}
}

/* Scrollbar Styling */
.chat-messages::-webkit-scrollbar,
.content-section::-webkit-scrollbar,
.sidebar-right::-webkit-scrollbar {
width: 6px;
}

.chat-messages::-webkit-scrollbar-track,
.content-section::-webkit-scrollbar-track,
.sidebar-right::-webkit-scrollbar-track {
background: var(--color-background);
}

.chat-messages::-webkit-scrollbar-thumb,
.content-section::-webkit-scrollbar-thumb,
.sidebar-right::-webkit-scrollbar-thumb {
background: var(--color-border);
border-radius: var(--radius-sm);
}

.chat-messages::-webkit-scrollbar-thumb:hover,
.content-section::-webkit-scrollbar-thumb:hover,
.sidebar-right::-webkit-scrollbar-thumb:hover {
background: var(--color-text-secondary);
}"""

# Truncate the CSS to fit in the string length limit - this is just the essential parts
project_files['static/style.css'] = css_content

print("Created static/style.css")